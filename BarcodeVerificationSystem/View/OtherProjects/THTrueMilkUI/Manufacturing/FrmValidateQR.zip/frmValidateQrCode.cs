﻿//using BarcodeVerificationSystem.View.THTrueMilkUI.Manufacturing;
//using Org.BouncyCastle.Asn1.Cmp;
//using System;
//using System.Drawing;
//using System.Drawing.Drawing2D;
//using System.Threading.Tasks;
//using System.Windows.Forms;

//namespace BarcodeVerificationSystem.View.OtherProjects.THTrueMilkUI.Manufacturing
//{
//    public partial class frmValidateQrCode : Form
//    {
//        public frmValidateQrCode()
//        {
//            InitializeComponent();

//            // Mở form luôn ở chế độ toàn màn hình
//            WindowState = FormWindowState.Maximized;

//            // Cho phép thay đổi kích thước form
//            FormBorderStyle = FormBorderStyle.Sizable;
//            MaximizeBox = true;
//            MinimizeBox = true;

//            // Kích thước nhỏ nhất của form
//            MinimumSize = new Size(1024, 648);

//            // Tắt Anchor cũ để tự tính lại vị trí responsive
//            pnlProductCard.Anchor = AnchorStyles.None;
//            pnlQrCard.Anchor = AnchorStyles.None;
//            pnlLinkCard.Anchor = AnchorStyles.None;
//            pnlCheckConfirm.Anchor = AnchorStyles.None;

//            InitState();
//            ApplyResponsiveLayout();
//        }

//        public string LinkSample
//        {
//            get { return txtLinkSample.Text; }
//            set { txtLinkSample.Text = value ?? string.Empty; }
//        }

//        public string ProductTitle
//        {
//            get { return lblProductName.Text; }
//            set { lblProductName.Text = string.IsNullOrWhiteSpace(value) ? "Sản phẩm mẫu" : value; }
//        }

//        public string JobCode
//        {
//            get { return lblJobCode.Text; }
//            set { lblJobCode.Text = string.IsNullOrWhiteSpace(value) ? "Mẫ sản phẩm: --" : "Mã sản phẩm: " + value; }
//        }

//        public Image ProductImage
//        {
//            get { return picProductImage.Image; }
//            set
//            {
//                picProductImage.Image = value;
//                lblProductPlaceholder.Visible = value == null;
//                if (value == null) lblProductPlaceholder.BringToFront();
//            }
//        }

//        public Image QrImage
//        {
//            get { return picQrSample.Image; }
//            set
//            {
//                picQrSample.Image = value;
//                lblQrPlaceholder.Visible = value == null;
//                if (value == null) lblQrPlaceholder.BringToFront();
//            }
//        }

//        public string NsxHsd
//        {
//            get { return lblNsxHsd.Text; }
//            set { lblNsxHsd.Text = value ?? string.Empty; }
//        }

//        public void SetValidateData(Image productImage, Image qrImage, string linkSample, string productName = "", string jobCode = "", string nsxHsd = "", string gtin = "")
//        {
//            ProductImage = productImage;
//            QrImage = qrImage;
//            LinkSample = linkSample;
//            ProductTitle = productName;
//            JobCode = jobCode;
//            NsxHsd = nsxHsd;
//            SetProductInfoDisplay(gtin, jobCode);

//            // Cảnh báo khi không tải được ảnh sản phẩm
//            if (productImage == null)
//            {
//                lblProductPlaceholder.Text = "Không tải được ảnh sản phẩm";
//                lblProductPlaceholder.ForeColor = System.Drawing.Color.Red;
//                lblProductPlaceholder.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
//            }
//        }

//        /// <summary>Load ảnh sản phẩm từ file local — dùng RAM cache, không block UI.</summary>
//        public void SetValidateDataFromLocal(string productLocalPath, Image qrImage, string linkSample, string productName = "", string jobCode = "", string nsxHsd = "", string gtin = "")
//        {
//            // Dùng ProductImageHelper để tận dụng RAM cache (Tier 0)
//            Image productImage = ProductImageHelper.GetProductImage(productLocalPath, null);

//            ProductImage = productImage;
//            QrImage = qrImage;
//            LinkSample = linkSample;
//            ProductTitle = productName;
//            JobCode = jobCode;
//            NsxHsd = nsxHsd;
//            SetProductInfoDisplay(gtin, jobCode);

//            if (productImage == null)
//            {
//                lblProductPlaceholder.Text = "Không tải được ảnh sản phẩm";
//                lblProductPlaceholder.ForeColor = System.Drawing.Color.Red;
//                lblProductPlaceholder.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
//            }
//        }

//        private void SetProductInfoDisplay(string gtin, string productCode)
//        {
//            rtbProductInfo.Clear();

//            string gtinLabel = "GTIN";
//            string codeLabel = "Mã sản phẩm";
//            int labelWidth = 16;

//            string gtinLine = gtinLabel.PadRight(labelWidth) + ": ";
//            string codeLine = codeLabel.PadRight(labelWidth) + ": ";

//            rtbProductInfo.AppendText("\n");
//            rtbProductInfo.AppendText(gtinLine);
//            rtbProductInfo.AppendText(gtin ?? "");
//            rtbProductInfo.AppendText("\n");
//            rtbProductInfo.AppendText("\n");
//            rtbProductInfo.AppendText(codeLine);
//            rtbProductInfo.AppendText(productCode ?? "");

//            if (!string.IsNullOrEmpty(gtin))
//            {
//                var boldFont = new Font(rtbProductInfo.Font, FontStyle.Bold);
//                var boldRedFont = new Font(rtbProductInfo.Font, FontStyle.Bold);
//                string fullText = rtbProductInfo.Text;

//                int gtinStart = fullText.IndexOf(gtin, StringComparison.Ordinal);
//                if (gtinStart >= 0)
//                {
//                    rtbProductInfo.Select(gtinStart, gtin.Length);
//                    rtbProductInfo.SelectionFont = boldFont;

//                    int last5Len = Math.Min(5, gtin.Length);
//                    string last5 = gtin.Substring(gtin.Length - last5Len);
//                    int idx5 = fullText.LastIndexOf(last5, StringComparison.Ordinal);
//                    if (idx5 >= 0)
//                    {
//                        rtbProductInfo.Select(idx5, last5Len);
//                        rtbProductInfo.SelectionFont = boldRedFont;
//                        rtbProductInfo.SelectionColor = Color.Red;
//                    }
//                }
//            }

//            if (!string.IsNullOrEmpty(productCode))
//            {
//                var boldFont = new Font(rtbProductInfo.Font, FontStyle.Bold);
//                string fullText = rtbProductInfo.Text;
//                int codeStart = fullText.IndexOf(productCode, StringComparison.Ordinal);
//                if (codeStart >= 0)
//                {
//                    rtbProductInfo.Select(codeStart, productCode.Length);
//                    rtbProductInfo.SelectionFont = boldFont;
//                }
//            }

//            rtbProductInfo.Select(0, 0);
//        }

//        private void InitState()
//        {
//            pnlConfirmOverlay.Visible = false;
//            chkProductImage.Checked = false;
//            chkQrContent.Checked = false;
//            btnContinue.Enabled = false;
//            lblProductPlaceholder.Visible = picProductImage.Image == null;
//            lblQrPlaceholder.Visible = picQrSample.Image == null;
//            if (lblProductPlaceholder.Visible) lblProductPlaceholder.BringToFront();
//            if (lblQrPlaceholder.Visible) lblQrPlaceholder.BringToFront();
//            UpdateContinueState();
//            CenterConfirmCard();
//        }

//        private void CheckConfirmChanged(object sender, EventArgs e)
//        {
//            UpdateContinueState();
//        }

//        private void UpdateContinueState()
//        {
//            bool isReady = chkProductImage.Checked && chkQrContent.Checked;

//            btnContinue.Enabled = isReady;
//            btnContinue.BackColor = isReady ? Color.FromArgb(0, 150, 70) : Color.FromArgb(180, 180, 180);
//            btnContinue.ForeColor = Color.White;

//            if (isReady)
//            {
//                lblStatus.Text = "ĐÃ XÁC NHẬN ĐỦ ĐIỀU KIỆN CÓ THỂ TIẾP TỤC.";
//                lblStatus.ForeColor = Color.FromArgb(0, 130, 60);
//            }
//            else
//            {
//                lblStatus.Text = "VUI LÒNG TICK ĐỦ 2 NỘI DUNG XÁC NHẬN TRƯỚC KHI TIẾP TỤC.";
//                lblStatus.ForeColor = Color.FromArgb(210, 100, 0);
//            }
//        }

//        private void btnContinue_Click(object sender, EventArgs e)
//        {
//            if (!chkProductImage.Checked || !chkQrContent.Checked)
//            {
//                MessageBox.Show(
//                    "Vui lòng xác nhận hình ảnh sản phẩm và QR Code / Link mẫu trước khi tiếp tục.",
//                    "Thiếu thông tin xác nhận",
//                    MessageBoxButtons.OK,
//                    MessageBoxIcon.Warning);
//                return;
//            }

//            pnlConfirmOverlay.Visible = true;
//            pnlConfirmOverlay.BringToFront();
//            CenterConfirmCard();
//            pnlFooter.Visible = false;
//        }

//        private void btnConfirmCancel_Click(object sender, EventArgs e)
//        {
//            pnlConfirmOverlay.Visible = false;
//            pnlFooter.Visible = true;
//        }

//        private async void btnConfirmOk_Click(object sender, EventArgs e)
//        {
//            pnlConfirmOverlay.Visible = true;
//            pnlConfirmOverlay.BringToFront();
//            CenterConfirmCard();
//            await Task.Delay(200);
//            DialogResult = DialogResult.OK;
//            Close();
//        }

//        private void btnCancel_Click(object sender, EventArgs e)
//        {
//            DialogResult = DialogResult.Cancel;
//            Close();
//        }

//        private void btnCopyLink_Click(object sender, EventArgs e)
//        {
//            try
//            {
//                if (!string.IsNullOrWhiteSpace(txtLinkSample.Text))
//                {
//                    Clipboard.SetText(txtLinkSample.Text.Trim());
//                    lblLinkNote.Text = "Đã copy link mẫu";
//                    lblLinkNote.ForeColor = Color.FromArgb(0, 130, 60);
//                }
//            }
//            catch
//            {
//                lblLinkNote.Text = "Không thể copy link mẫu";
//                lblLinkNote.ForeColor = Color.FromArgb(200, 80, 0);
//            }
//        }

//        private void frmValidateQrCode_Resize(object sender, EventArgs e)
//        {
//            ApplyResponsiveLayout();
//            CenterConfirmCard();
//        }
//        private void ApplyResponsiveLayout()
//        {
//            if (pnlContent == null ||
//                pnlContent.ClientSize.Width <= 0 ||
//                pnlContent.ClientSize.Height <= 0)
//            {
//                return;
//            }

//            int contentWidth = pnlContent.ClientSize.Width;
//            int contentHeight = pnlContent.ClientSize.Height;

//            int margin = 28;
//            int gap = 32;

//            // Khu vực thông báo xác nhận phía dưới
//            int confirmHeight = 81;
//            int confirmBottomMargin = 17;
//            int confirmTop = contentHeight - confirmHeight - confirmBottomMargin;

//            pnlCheckConfirm.SetBounds(
//                margin,
//                confirmTop,
//                Math.Max(300, contentWidth - margin * 2),
//                confirmHeight
//            );

//            // Chia đều 3 khối: sản phẩm, QR và link
//            int cardTop = 43;
//            int cardBottomMargin = 25;

//            int cardHeight = Math.Max(
//                280,
//                confirmTop - cardTop - cardBottomMargin
//            );

//            int availableWidth =
//                contentWidth -
//                margin * 2 -
//                gap * 2;

//            int cardWidth = Math.Max(
//                250,
//                availableWidth / 3
//            );

//            int productLeft = margin;
//            int qrLeft = productLeft + cardWidth + gap;
//            int linkLeft = qrLeft + cardWidth + gap;

//            pnlProductCard.SetBounds(
//                productLeft,
//                cardTop,
//                cardWidth,
//                cardHeight
//            );

//            pnlQrCard.SetBounds(
//                qrLeft,
//                cardTop,
//                cardWidth,
//                cardHeight
//            );

//            pnlLinkCard.SetBounds(
//                linkLeft,
//                cardTop,
//                cardWidth,
//                cardHeight
//            );

//            ApplyProductCardLayout(cardWidth, cardHeight);
//            ApplyQrCardLayout(cardWidth, cardHeight);
//            ApplyLinkCardLayout(cardWidth, cardHeight);

//            // Mã sản phẩm luôn nằm góc trên bên phải
//            lblJobCode.Left =
//                contentWidth -
//                margin -
//                lblJobCode.Width;

//            if (pnlConfirmOverlay.Visible)
//            {
//                pnlConfirmOverlay.BringToFront();
//            }
//        }

//        private void ApplyProductCardLayout(
//    int cardWidth,
//    int cardHeight)
//        {
//            int sideMargin = 20;
//            int checkHeight = 48;

//            int checkTop =
//                cardHeight -
//                checkHeight -
//                4;

//            // Đưa productNameTop lên cao hơn để có chỗ cho lblNsxHsd
//            int productNameTop =
//                checkTop -
//                94;

//            int imageTop = 58;

//            int imageHeight = Math.Max(
//                100,
//                productNameTop -
//                imageTop -
//                8
//            );

//            picProductImage.SetBounds(
//                sideMargin,
//                imageTop,
//                Math.Max(100, cardWidth - sideMargin * 2),
//                imageHeight
//            );

//            lblProductPlaceholder.SetBounds(
//                picProductImage.Left,
//                picProductImage.Top +
//                Math.Max(0, (picProductImage.Height - 24) / 2),
//                picProductImage.Width,
//                24
//            );

//            lblProductName.SetBounds(
//                sideMargin,
//                productNameTop,
//                Math.Max(100, cardWidth - sideMargin * 2),
//                28
//            );

//            // lblNsxHsd nằm giữa lblProductName và chkProductImage
//            lblNsxHsd.SetBounds(
//                sideMargin,
//                productNameTop + 32,
//                Math.Max(100, cardWidth - sideMargin * 2),
//                50
//            );

//            chkProductImage.SetBounds(
//                10,
//                checkTop,
//                Math.Max(100, cardWidth - 16),
//                checkHeight
//            );

//            if (lblProductPlaceholder.Visible)
//            {
//                lblProductPlaceholder.BringToFront();
//            }
//        }
//        private void ApplyQrCardLayout(
//    int cardWidth,
//    int cardHeight)
//        {
//            int checkHeight = 48;

//            int checkTop =
//                cardHeight -
//                checkHeight -
//                4;

//            int qrAreaTop = 55;

//            int qrAreaHeight = Math.Max(
//                100,
//                checkTop -
//                qrAreaTop -
//                12
//            );

//            int qrSize = Math.Min(
//                cardWidth - 30,
//                qrAreaHeight
//            );

//            qrSize = Math.Max(140, qrSize);

//            int qrLeft =
//                Math.Max(15, (cardWidth - qrSize) / 2);

//            int qrTop =
//                qrAreaTop +
//                Math.Max(0, (qrAreaHeight - qrSize) / 2);

//            picQrSample.SetBounds(
//                qrLeft,
//                qrTop,
//                qrSize,
//                qrSize
//            );

//            lblQrPlaceholder.SetBounds(
//                picQrSample.Left,
//                picQrSample.Top +
//                Math.Max(0, (picQrSample.Height - 24) / 2),
//                picQrSample.Width,
//                24
//            );

//            chkQrContent.SetBounds(
//                6,
//                checkTop,
//                Math.Max(100, cardWidth - 12),
//                checkHeight
//            );

//            if (lblQrPlaceholder.Visible)
//            {
//                lblQrPlaceholder.BringToFront();
//            }
//        }
//        private void ApplyLinkCardLayout(
//    int cardWidth,
//    int cardHeight)
//        {
//            int sideMargin = 12;
//            int gap = 8;
//            int bottomMargin = 8;

//            int infoTitleHeight = 36;
//            int separatorHeight = 1;

//            int textTop = lblLinkTitle.Bottom + label1.Height + 4;

//            int textWidth = Math.Max(
//                120,
//                cardWidth - sideMargin * 2);

//            int textHeight = Math.Max(
//                60,
//                cardHeight
//                - textTop
//                - gap
//                - 36
//                - gap
//                - separatorHeight
//                - gap
//                - infoTitleHeight
//                - gap
//                - 140
//                - bottomMargin);

//            txtLinkSample.SetBounds(
//                sideMargin,
//                textTop,
//                textWidth,
//                textHeight);

//            int buttonWidth = Math.Min(
//                190,
//                textWidth);

//            btnCopyLink.SetBounds(
//                (cardWidth - buttonWidth) / 2,
//                txtLinkSample.Bottom + gap,
//                buttonWidth + 10,
//                36);

//            lblSeparator.SetBounds(
//                sideMargin,
//                btnCopyLink.Bottom + gap,
//                textWidth,
//                separatorHeight);

//            lblInfoTitle.SetBounds(
//                0,
//                lblSeparator.Bottom + gap,
//                cardWidth,
//                infoTitleHeight);

//            rtbProductInfo.SetBounds(
//                sideMargin,
//                lblInfoTitle.Bottom + 4,
//                textWidth,
//                140);
//        }

//        //    private void ApplyLinkCardLayout(
//        //int cardWidth,
//        //int cardHeight)
//        //    {
//        //        int sideMargin = 20;
//        //        int textWidth = Math.Max(
//        //            100,
//        //            cardWidth - sideMargin * 2
//        //        );

//        //        int totalGroupHeight = 600;

//        //        int contentTop =
//        //            40 +
//        //            Math.Max(
//        //                20,
//        //                (cardHeight - 40 - totalGroupHeight) / 2
//        //            );

//        //        txtLinkSample.SetBounds(
//        //            sideMargin,
//        //            contentTop,
//        //            textWidth,
//        //            320
//        //        );

//        //        int buttonWidth = Math.Min(
//        //            187,
//        //            textWidth
//        //        );

//        //        btnCopyLink.SetBounds(
//        //            Math.Max(
//        //                sideMargin,
//        //                (cardWidth - buttonWidth) / 2
//        //            ),
//        //            txtLinkSample.Bottom + 12,
//        //            buttonWidth,
//        //            34
//        //        );

//        //        lblLinkNote.SetBounds(
//        //            sideMargin,
//        //            btnCopyLink.Bottom + 8,
//        //            textWidth,
//        //            56
//        //        );
//        //    }
//        private void CenterConfirmCard()
//        {
//            if (pnlConfirmOverlay == null || pnlConfirmCard == null)
//                return;

//            pnlConfirmCard.Left = (pnlConfirmOverlay.Width - pnlConfirmCard.Width) / 2;
//            pnlConfirmCard.Top = (pnlConfirmOverlay.Height - pnlConfirmCard.Height) / 2;
//        }

//        private void label1_Click(object sender, EventArgs e)
//        {

//        }
//    }

//    /// <summary>
//    /// CheckBox tùy chỉnh: chỉ tăng kích thước ô vuông, giữ nguyên cỡ chữ.
//    /// Đặt trong cùng namespace và cùng file để WinForms Designer luôn nhận diện.
//    /// </summary>
//    public class LargeCheckBox : CheckBox
//    {
//        private int checkBoxSize = 28;

//        public int CheckBoxSize
//        {
//            get { return checkBoxSize; }
//            set
//            {
//                checkBoxSize = Math.Max(16, value);
//                Invalidate();
//            }
//        }

//        public LargeCheckBox()
//        {
//            AutoSize = false;

//            SetStyle(
//                ControlStyles.UserPaint |
//                ControlStyles.AllPaintingInWmPaint |
//                ControlStyles.OptimizedDoubleBuffer |
//                ControlStyles.ResizeRedraw,
//                true);
//        }

//        protected override void OnPaint(PaintEventArgs e)
//        {
//            e.Graphics.Clear(BackColor);
//            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

//            int boxTop = Math.Max(0, (Height - CheckBoxSize) / 2);

//            Rectangle boxRectangle = new Rectangle(
//                1,
//                boxTop,
//                CheckBoxSize - 2,
//                CheckBoxSize - 2);

//            Color borderColor = Enabled
//                ? Color.FromArgb(105, 115, 125)
//                : Color.FromArgb(180, 180, 180);

//            Color fillColor = Checked
//                ? Color.FromArgb(0, 150, 70)
//                : Color.White;

//            using (SolidBrush fillBrush = new SolidBrush(fillColor))
//            using (Pen borderPen = new Pen(borderColor, 1.5F))
//            {
//                e.Graphics.FillRectangle(fillBrush, boxRectangle);
//                e.Graphics.DrawRectangle(borderPen, boxRectangle);
//            }

//            if (Checked)
//            {
//                PointF[] checkPoints =
//                {
//                    new PointF(
//                        boxRectangle.Left + boxRectangle.Width * 0.20F,
//                        boxRectangle.Top + boxRectangle.Height * 0.52F),

//                    new PointF(
//                        boxRectangle.Left + boxRectangle.Width * 0.43F,
//                        boxRectangle.Top + boxRectangle.Height * 0.74F),

//                    new PointF(
//                        boxRectangle.Left + boxRectangle.Width * 0.82F,
//                        boxRectangle.Top + boxRectangle.Height * 0.27F)
//                };

//                using (Pen checkPen = new Pen(
//                    Color.White,
//                    Math.Max(2.5F, CheckBoxSize / 9F)))
//                {
//                    checkPen.StartCap = LineCap.Round;
//                    checkPen.EndCap = LineCap.Round;
//                    checkPen.LineJoin = LineJoin.Round;
//                    e.Graphics.DrawLines(checkPen, checkPoints);
//                }
//            }

//            Rectangle textRectangle = new Rectangle(
//                CheckBoxSize + 9,
//                0,
//                Math.Max(0, Width - CheckBoxSize - 9),
//                Height);

//            TextRenderer.DrawText(
//                e.Graphics,
//                Text,
//                Font,
//                textRectangle,
//                Enabled ? ForeColor : SystemColors.GrayText,
//                TextFormatFlags.Left |
//                TextFormatFlags.VerticalCenter |
//                TextFormatFlags.NoPadding |
//                TextFormatFlags.SingleLine);

//            if (Focused && ShowFocusCues)
//            {
//                Rectangle focusRectangle = textRectangle;
//                focusRectangle.Inflate(-1, -4);
//                ControlPaint.DrawFocusRectangle(e.Graphics, focusRectangle);
//            }
//        }

//        protected override void OnCheckedChanged(EventArgs e)
//        {
//            base.OnCheckedChanged(e);
//            Invalidate();
//        }

//        protected override void OnEnabledChanged(EventArgs e)
//        {
//            base.OnEnabledChanged(e);
//            Invalidate();
//        }

//        protected override void OnGotFocus(EventArgs e)
//        {
//            base.OnGotFocus(e);
//            Invalidate();
//        }

//        protected override void OnLostFocus(EventArgs e)
//        {
//            base.OnLostFocus(e);
//            Invalidate();
//        }
//    }
//}
using BarcodeVerificationSystem.View.THTrueMilkUI.Manufacturing;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BarcodeVerificationSystem.View.OtherProjects.THTrueMilkUI.Manufacturing
{
    public partial class frmValidateQrCode : Form
    {
        public frmValidateQrCode()
        {
            InitializeComponent();

            // Mở form luôn ở chế độ toàn màn hình
            WindowState = FormWindowState.Maximized;

            // Cho phép thay đổi kích thước form
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true;
            MinimizeBox = true;

            // Kích thước nhỏ nhất của form
            MinimumSize = new Size(1024, 648);

            // Tắt Anchor cũ để tự tính lại vị trí responsive
            pnlProductCard.Anchor = AnchorStyles.None;
            pnlQrCard.Anchor = AnchorStyles.None;
            pnlLinkCard.Anchor = AnchorStyles.None;
            pnlCheckConfirm.Anchor = AnchorStyles.None;

            InitCustomUI(); // Tùy chỉnh màu sắc, viền cho giống thiết kế
            InitState();
            ApplyResponsiveLayout();
        }

        private void InitCustomUI()
        {
            // Ép viền cho 3 thẻ Panel
            pnlProductCard.BorderStyle = BorderStyle.FixedSingle;
            pnlQrCard.BorderStyle = BorderStyle.FixedSingle;
            pnlLinkCard.BorderStyle = BorderStyle.FixedSingle;

            // Đưa 2 checkbox ra ngoài Panel Content để nằm dưới các thẻ giống hình
            pnlContent.Controls.Add(chkProductImage);
            pnlContent.Controls.Add(chkQrContent);

            // Cập nhật màu sắc chữ tiêu đề để giống hình (Xanh đậm)
            Color headerBackColor = Color.FromArgb(235, 243, 252);
            Color headerForeColor = Color.FromArgb(0, 85, 160);

            lblProductTitle.BackColor = headerBackColor;
            lblProductTitle.ForeColor = headerForeColor;
            lblQrTitle.BackColor = headerBackColor;
            lblQrTitle.ForeColor = headerForeColor;
            lblLinkTitle.BackColor = headerBackColor;
            lblLinkTitle.ForeColor = headerForeColor;

            // Đổi màu chữ Checkbox sang màu đen thay vì màu đỏ
            chkProductImage.ForeColor = Color.FromArgb(45, 55, 65);
            chkQrContent.ForeColor = Color.FromArgb(45, 55, 65);

            // Đổi màu nền thanh trạng thái dưới cùng
            pnlCheckConfirm.BackColor = Color.FromArgb(255, 250, 240); // Vàng nhạt/Cam nhạt

            // Căn giữa chữ hiển thị
            lblProductName.TextAlign = ContentAlignment.MiddleCenter;
            label1.TextAlign = ContentAlignment.MiddleCenter;
            lblInfoTitle.TextAlign = ContentAlignment.MiddleCenter;
        }

        public string LinkSample
        {
            get { return txtLinkSample.Text; }
            set { txtLinkSample.Text = value ?? string.Empty; }
        }

        public string ProductTitle
        {
            get { return lblProductName.Text; }
            set { lblProductName.Text = string.IsNullOrWhiteSpace(value) ? "Sản phẩm mẫu" : value; }
        }

        public string JobCode
        {
            get { return lblJobCode.Text; }
            set { lblJobCode.Text = string.IsNullOrWhiteSpace(value) ? "Mã sản phẩm: --" : "Mã sản phẩm: " + value; }
        }

        public Image ProductImage
        {
            get { return picProductImage.Image; }
            set
            {
                picProductImage.Image = value;
                lblProductPlaceholder.Visible = value == null;
                if (value == null) lblProductPlaceholder.BringToFront();
            }
        }

        public Image QrImage
        {
            get { return picQrSample.Image; }
            set
            {
                picQrSample.Image = value;
                lblQrPlaceholder.Visible = value == null;
                if (value == null) lblQrPlaceholder.BringToFront();
            }
        }

        public string NsxHsd
        {
            get { return lblNsxHsd.Text; }
            set { lblNsxHsd.Text = value ?? string.Empty; }
        }

        public void SetValidateData(Image productImage, Image qrImage, string linkSample, string productName = "", string jobCode = "", string nsxHsd = "", string gtin = "")
        {
            ProductImage = productImage;
            QrImage = qrImage;
            LinkSample = linkSample;
            ProductTitle = productName;
            JobCode = jobCode;
            NsxHsd = nsxHsd;
            SetProductInfoDisplay(gtin, jobCode);

            if (productImage == null)
            {
                lblProductPlaceholder.Text = "Không tải được ảnh sản phẩm";
                lblProductPlaceholder.ForeColor = Color.Red;
                lblProductPlaceholder.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            }
        }

        public void SetValidateDataFromLocal(string productLocalPath, Image qrImage, string linkSample, string productName = "", string jobCode = "", string nsxHsd = "", string gtin = "")
        {
            Image productImage = ProductImageHelper.GetProductImage(productLocalPath, null);

            ProductImage = productImage;
            QrImage = qrImage;
            LinkSample = linkSample;
            ProductTitle = productName;
            JobCode = jobCode;
            NsxHsd = nsxHsd;
            SetProductInfoDisplay(gtin, jobCode);

            if (productImage == null)
            {
                lblProductPlaceholder.Text = "Không tải được ảnh sản phẩm";
                lblProductPlaceholder.ForeColor = Color.Red;
                lblProductPlaceholder.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            }
        }

        private void SetProductInfoDisplay(string gtin, string productCode)
        {
            rtbProductInfo.Clear();

            string gtinLabel = "GTIN";
            string codeLabel = "Mã sản phẩm";
            int labelWidth = 16;

            string gtinLine = gtinLabel.PadRight(labelWidth) + ": ";
            string codeLine = codeLabel.PadRight(labelWidth) + ": ";

            rtbProductInfo.AppendText("\n");
            rtbProductInfo.AppendText(gtinLine);
            rtbProductInfo.AppendText(gtin ?? "");
            rtbProductInfo.AppendText("\n\n");
            rtbProductInfo.AppendText(codeLine);
            rtbProductInfo.AppendText(productCode ?? "");

            if (!string.IsNullOrEmpty(gtin))
            {
                var boldFont = new Font(rtbProductInfo.Font, FontStyle.Bold);
                var boldRedFont = new Font(rtbProductInfo.Font, FontStyle.Bold);
                string fullText = rtbProductInfo.Text;

                int gtinStart = fullText.IndexOf(gtin, StringComparison.Ordinal);
                if (gtinStart >= 0)
                {
                    rtbProductInfo.Select(gtinStart, gtin.Length);
                    rtbProductInfo.SelectionFont = boldFont;

                    int last5Len = Math.Min(5, gtin.Length);
                    string last5 = gtin.Substring(gtin.Length - last5Len);
                    int idx5 = fullText.LastIndexOf(last5, StringComparison.Ordinal);
                    if (idx5 >= 0)
                    {
                        rtbProductInfo.Select(idx5, last5Len);
                        rtbProductInfo.SelectionFont = boldRedFont;
                        rtbProductInfo.SelectionColor = Color.Red;
                    }
                }
            }

            if (!string.IsNullOrEmpty(productCode))
            {
                var boldFont = new Font(rtbProductInfo.Font, FontStyle.Bold);
                string fullText = rtbProductInfo.Text;
                int codeStart = fullText.IndexOf(productCode, StringComparison.Ordinal);
                if (codeStart >= 0)
                {
                    rtbProductInfo.Select(codeStart, productCode.Length);
                    rtbProductInfo.SelectionFont = boldFont;
                }
            }

            rtbProductInfo.Select(0, 0);
        }

        private void InitState()
        {
            pnlConfirmOverlay.Visible = false;
            chkProductImage.Checked = false;
            chkQrContent.Checked = false;
            btnContinue.Enabled = false;
            lblProductPlaceholder.Visible = picProductImage.Image == null;
            lblQrPlaceholder.Visible = picQrSample.Image == null;
            if (lblProductPlaceholder.Visible) lblProductPlaceholder.BringToFront();
            if (lblQrPlaceholder.Visible) lblQrPlaceholder.BringToFront();
            UpdateContinueState();
            CenterConfirmCard();
        }

        private void CheckConfirmChanged(object sender, EventArgs e)
        {
            UpdateContinueState();
        }

        private void UpdateContinueState()
        {
            bool isReady = chkProductImage.Checked && chkQrContent.Checked;

            btnContinue.Enabled = isReady;
            btnContinue.BackColor = isReady ? Color.FromArgb(0, 150, 70) : Color.FromArgb(180, 180, 180);
            btnContinue.ForeColor = Color.White;

            if (isReady)
            {
                lblStatus.Text = "ĐÃ XÁC NHẬN ĐỦ ĐIỀU KIỆN CÓ THỂ TIẾP TỤC.";
                lblStatus.ForeColor = Color.FromArgb(0, 130, 60);
            }
            else
            {
                lblStatus.Text = "VUI LÒNG TICK ĐỦ 2 NỘI DUNG XÁC NHẬN TRƯỚC KHI TIẾP TỤC.";
                lblStatus.ForeColor = Color.Red;
            }
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            if (!chkProductImage.Checked || !chkQrContent.Checked)
            {
                MessageBox.Show(
                    "Vui lòng xác nhận hình ảnh sản phẩm và QR Code / Link mẫu trước khi tiếp tục.",
                    "Thiếu thông tin xác nhận",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            pnlConfirmOverlay.Visible = true;
            pnlConfirmOverlay.BringToFront();
            CenterConfirmCard();
            pnlFooter.Visible = false;
        }

        private void btnConfirmCancel_Click(object sender, EventArgs e)
        {
            pnlConfirmOverlay.Visible = false;
            pnlFooter.Visible = true;
        }

        private async void btnConfirmOk_Click(object sender, EventArgs e)
        {
            pnlConfirmOverlay.Visible = true;
            pnlConfirmOverlay.BringToFront();
            CenterConfirmCard();
            await Task.Delay(200);
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void btnCopyLink_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(txtLinkSample.Text))
                {
                    Clipboard.SetText(txtLinkSample.Text.Trim());
                    lblLinkNote.Text = "Đã copy link mẫu";
                    lblLinkNote.ForeColor = Color.FromArgb(0, 130, 60);
                }
            }
            catch
            {
                lblLinkNote.Text = "Không thể copy link mẫu";
                lblLinkNote.ForeColor = Color.FromArgb(200, 80, 0);
            }
        }

        private void frmValidateQrCode_Resize(object sender, EventArgs e)
        {
            ApplyResponsiveLayout();
            CenterConfirmCard();
        }

        private void ApplyResponsiveLayout()
        {
            if (pnlContent == null || pnlContent.ClientSize.Width <= 0 || pnlContent.ClientSize.Height <= 0)
                return;

            int contentWidth = pnlContent.ClientSize.Width;
            int contentHeight = pnlContent.ClientSize.Height;

            int marginX = 25; // Lề 2 bên
            int gapX = 20;    // Khoảng cách giữa các thẻ

            // 1. Thanh trạng thái phía dưới
            int confirmHeight = 75;
            int confirmBottomMargin = 15;
            int confirmTop = contentHeight - confirmHeight - confirmBottomMargin;

            pnlCheckConfirm.SetBounds(marginX, confirmTop, contentWidth - marginX * 2, confirmHeight);

            // 2. Tính toán 3 Cột (Cards)
            int checkHeight = 45;      // Chiều cao cho 2 dòng checkbox
            int cardBottomMargin = 15;
            int cardTop = 20;

            // Tính độ cao các thẻ (trừ đi khoảng không gian để chứa Checkbox dưới cùng)
            int cardHeight = confirmTop - cardTop - cardBottomMargin - checkHeight - 10;

            int availableWidth = contentWidth - (marginX * 2) - (gapX * 2);
            int cardWidth = Math.Max(250, availableWidth / 3);

            int col1Left = marginX;
            int col2Left = col1Left + cardWidth + gapX;
            int col3Left = col2Left + cardWidth + gapX;

            pnlProductCard.SetBounds(col1Left, cardTop, cardWidth, cardHeight);
            pnlQrCard.SetBounds(col2Left, cardTop, cardWidth, cardHeight);
            pnlLinkCard.SetBounds(col3Left, cardTop, cardWidth, cardHeight);

            // 3. Đặt Checkbox thẳng hàng ngay dưới thẻ (Căn lề)
            int checkboxTop = pnlProductCard.Bottom + 10;
            chkProductImage.SetBounds(col1Left + 20, checkboxTop, cardWidth, checkHeight);
            chkQrContent.SetBounds(col2Left + 20, checkboxTop, cardWidth * 2, checkHeight); // Cột 2 có thể tràn chữ sang cột 3

            // Bố trí nội dung bên trong từng thẻ
            ApplyProductCardLayout(cardWidth, cardHeight);
            ApplyQrCardLayout(cardWidth, cardHeight);
            ApplyLinkCardLayout(cardWidth, cardHeight);

            lblJobCode.Visible = false; // Tắt mã JobCode ở góc để giống ảnh thiết kế

            if (pnlConfirmOverlay.Visible)
            {
                pnlConfirmOverlay.BringToFront();
            }
        }

        private void ApplyProductCardLayout(int cardWidth, int cardHeight)
        {
            int titleHeight = 40;
            lblProductTitle.SetBounds(0, 0, cardWidth, titleHeight);

            int nameLabelHeight = 60;
            // Tên sản phẩm căn dưới cùng
            lblProductName.SetBounds(10, cardHeight - nameLabelHeight - 10, cardWidth - 20, nameLabelHeight);

            int imageTop = titleHeight + 15;
            int imageHeight = lblProductName.Top - imageTop - 10;

            picProductImage.SetBounds(10, imageTop, cardWidth - 20, imageHeight);

            lblProductPlaceholder.SetBounds(
                picProductImage.Left,
                picProductImage.Top + Math.Max(0, (picProductImage.Height - 24) / 2),
                picProductImage.Width, 24);
        }

        private void ApplyQrCardLayout(int cardWidth, int cardHeight)
        {
            int titleHeight = 40;
            lblQrTitle.SetBounds(0, 0, cardWidth, titleHeight);

            int qrAreaHeight = cardHeight - titleHeight;
            int qrSize = Math.Min(cardWidth - 60, qrAreaHeight - 40);
            qrSize = Math.Max(150, qrSize);

            int qrLeft = Math.Max(10, (cardWidth - qrSize) / 2);
            int qrTop = titleHeight + Math.Max(10, (qrAreaHeight - qrSize) / 2);

            picQrSample.SetBounds(qrLeft, qrTop, qrSize, qrSize);

            lblQrPlaceholder.SetBounds(
                picQrSample.Left,
                picQrSample.Top + Math.Max(0, (picQrSample.Height - 24) / 2),
                picQrSample.Width, 24);
        }

        private void ApplyLinkCardLayout(int cardWidth, int cardHeight)
        {
            int titleHeight = 40;
            lblLinkTitle.SetBounds(0, 0, cardWidth, titleHeight);

            label1.SetBounds(10, titleHeight + 15, cardWidth - 20, 30);

            txtLinkSample.SetBounds(15, label1.Bottom + 5, cardWidth - 30, 80);

            // Căn giữa nút bấm copy
            int btnWidth = 220;
            int btnLeft = Math.Max(15, (cardWidth - btnWidth) / 2);
            btnCopyLink.SetBounds(btnLeft, txtLinkSample.Bottom + 15, btnWidth, 40);

            lblSeparator.SetBounds(15, btnCopyLink.Bottom + 20, cardWidth - 30, 1);

            lblInfoTitle.SetBounds(10, lblSeparator.Bottom + 15, cardWidth - 20, 30);

            rtbProductInfo.SetBounds(25, lblInfoTitle.Bottom + 10, cardWidth - 50, cardHeight - lblInfoTitle.Bottom - 15);
        }

        private void CenterConfirmCard()
        {
            if (pnlConfirmOverlay == null || pnlConfirmCard == null) return;
            pnlConfirmCard.Left = (pnlConfirmOverlay.Width - pnlConfirmCard.Width) / 2;
            pnlConfirmCard.Top = (pnlConfirmOverlay.Height - pnlConfirmCard.Height) / 2;
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }
    }

    /// <summary>
    /// CheckBox tùy chỉnh: Vẽ ô vuông màu xanh có bo góc nhạt giống thiết kế
    /// </summary>
    public class LargeCheckBox : CheckBox
    {
        private int checkBoxSize = 28;

        public int CheckBoxSize
        {
            get { return checkBoxSize; }
            set
            {
                checkBoxSize = Math.Max(16, value);
                Invalidate();
            }
        }

        public LargeCheckBox()
        {
            AutoSize = false;
            SetStyle(
                ControlStyles.UserPaint |
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw,
                true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            int boxTop = Math.Max(0, (Height - CheckBoxSize) / 2);
            Rectangle boxRectangle = new Rectangle(1, boxTop, CheckBoxSize - 2, CheckBoxSize - 2);

            Color borderColor = Enabled ? Color.FromArgb(105, 115, 125) : Color.FromArgb(180, 180, 180);

            // Đổi màu fill thành màu xanh lá cây chuẩn như thiết kế khi được Checked
            Color fillColor = Checked ? Color.FromArgb(0, 150, 70) : Color.White;

            using (SolidBrush fillBrush = new SolidBrush(fillColor))
            using (Pen borderPen = new Pen(Checked ? fillColor : borderColor, 1.5F))
            {
                // Fill hình vuông
                e.Graphics.FillRectangle(fillBrush, boxRectangle);
                e.Graphics.DrawRectangle(borderPen, boxRectangle);
            }

            // Vẽ dấu tích màu trắng bên trong nền xanh
            if (Checked)
            {
                PointF[] checkPoints =
                {
                    new PointF(boxRectangle.Left + boxRectangle.Width * 0.22F, boxRectangle.Top + boxRectangle.Height * 0.50F),
                    new PointF(boxRectangle.Left + boxRectangle.Width * 0.42F, boxRectangle.Top + boxRectangle.Height * 0.72F),
                    new PointF(boxRectangle.Left + boxRectangle.Width * 0.78F, boxRectangle.Top + boxRectangle.Height * 0.28F)
                };

                using (Pen checkPen = new Pen(Color.White, Math.Max(2.5F, CheckBoxSize / 8F)))
                {
                    checkPen.StartCap = LineCap.Round;
                    checkPen.EndCap = LineCap.Round;
                    checkPen.LineJoin = LineJoin.Round;
                    e.Graphics.DrawLines(checkPen, checkPoints);
                }
            }

            Rectangle textRectangle = new Rectangle(CheckBoxSize + 9, 0, Math.Max(0, Width - CheckBoxSize - 9), Height);

            TextRenderer.DrawText(
                e.Graphics,
                Text,
                Font,
                textRectangle,
                Enabled ? ForeColor : SystemColors.GrayText,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine);

            if (Focused && ShowFocusCues)
            {
                Rectangle focusRectangle = textRectangle;
                focusRectangle.Inflate(-1, -4);
                ControlPaint.DrawFocusRectangle(e.Graphics, focusRectangle);
            }
        }

        protected override void OnCheckedChanged(EventArgs e)
        {
            base.OnCheckedChanged(e);
            Invalidate();
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            base.OnEnabledChanged(e);
            Invalidate();
        }

        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            Invalidate();
        }

        protected override void OnLostFocus(EventArgs e)
        {
            base.OnLostFocus(e);
            Invalidate();
        }
    }
}
